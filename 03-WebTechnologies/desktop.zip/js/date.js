function date1(){
var today = new Date();
alert(today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate());
}