var x=0
function click1(){
    x++;
    alert("You clicked button "+x+' times!')
}